Copilot Agent — AI‑Blockchain Website Skeleton (v2, Windows‑friendly, EN)

You are operating inside a repo that already contains a Next.js app in the subfolder `site/` created with the App Router and `--src-dir`.
Your task: finish the **content website skeleton** (English‑only) and make it run locally with Tailwind CSS v3 — without using `npx tailwindcss init`.

IMPORTANT RULES
- Work **inside the `site/` directory** only. Do not touch parent folders.
- Use **TypeScript** everywhere. App Router in `src/app/`.
- Keep deps minimal: `tailwindcss@3`, `postcss`, `autoprefixer` (no extra plugins, no AI SDKs).
- English copy + metadata. `<html lang="en">`.
- **Do NOT** run `npx tailwindcss init`. We configure files manually.
- After each step, print a short summary of what changed.

ACCEPTANCE CRITERIA
- `npm run dev` serves http://localhost:3000 without TypeScript errors.
- Tailwind works (utility classes take effect).
- Pages exist: `/` (Home), `/about`, `/idea`.
- Global layout with `Header` + `Footer`.
- Basic SEO: Metadata API + `src/app/sitemap.ts` + `src/app/robots.ts`.
- Public OG image placeholder at `public/og.svg` is referenced by metadata.

--------------------------------------------------------------------------------
STEP 0 — Switch to the correct working directory
- Open an integrated terminal **inside `site/`**.
- Verify versions:
  - `node -v`
  - `npm -v`

If terminal policies block commands in PowerShell, prefer `cmd` terminal. We do NOT require `npx` in this plan.

--------------------------------------------------------------------------------
STEP 1 — Ensure the correct dev dependencies
- Check if `tailwindcss`, `postcss`, `autoprefixer` are present:
  - `npm ls tailwindcss` (should be 3.x)
  - `npm ls postcss`
  - `npm ls autoprefixer`
- If `@tailwindcss/postcss` is installed, remove it (belongs to v4):
  - `npm rm -D @tailwindcss/postcss` (ignore errors if not found)
- If any of the three are missing, install them:
  - `npm i -D tailwindcss@3 postcss autoprefixer`

Output what changed.

--------------------------------------------------------------------------------
STEP 2 — Create/overwrite Tailwind + PostCSS configs (manual, no CLI)
Create or overwrite these files at the **root of `site/`**:

`tailwind.config.ts`
```ts
import type { Config } from 'tailwindcss'

export default {
  content: ['./src/app/**/*.{ts,tsx}', './src/components/**/*.{ts,tsx}', './src/lib/**/*.{ts,tsx}'],
  theme: { extend: {} },
  plugins: [],
} satisfies Config
```

`postcss.config.mjs`
```js
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
```

--------------------------------------------------------------------------------
STEP 3 — Global stylesheet (Tailwind directives)
Overwrite `src/app/globals.css` with:
```css
@tailwind base;
@tailwind components;
@tailwind utilities;

:root { color-scheme: light; }
body { @apply bg-white text-gray-800 antialiased; }
```

Ensure `src/app/layout.tsx` imports `./globals.css` (Next scaffold usually does).

--------------------------------------------------------------------------------
STEP 4 — Site constants + layout shell
Create `src/lib/site.ts`:
```ts
export const SITE = {
  url: 'http://localhost:3000', // change in production
  name: 'AI-Blockchain',
  tagline: 'Miners power AI and get paid',
  description:
    'We are building a blockchain where miners contribute compute to train and run AI and are rewarded with cryptocurrency.',
}
```

Edit/overwrite `src/app/layout.tsx` to this content:
```tsx
import type { Metadata } from 'next'
import './globals.css'
import Header from '@/components/Header'
import Footer from '@/components/Footer'
import { SITE } from '@/lib/site'

export const metadata: Metadata = {
  metadataBase: new URL(SITE.url),
  title: { default: SITE.name, template: `%s | ${SITE.name}` },
  description: SITE.description,
  openGraph: {
    title: SITE.name,
    description: SITE.description,
    url: SITE.url,
    siteName: SITE.name,
    images: [{ url: '/og.svg', width: 1200, height: 630 }],
    locale: 'en_US',
    type: 'website',
  },
  twitter: { card: 'summary_large_image', title: SITE.name, description: SITE.description, images: ['/og.svg'] },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-dvh flex flex-col">
        <Header />
        <main className="flex-1">{children}</main>
        <Footer />
      </body>
    </html>
  )
}
```

Create `src/components/Header.tsx`:
```tsx
export default function Header() {
  return (
    <header className="sticky top-0 z-50 border-b bg-white/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
        <a href="/" className="text-base font-semibold">AI-Blockchain</a>
        <nav className="flex items-center gap-4 text-sm">
          <a href="/#features" className="hover:underline">Features</a>
          <a href="/idea" className="hover:underline">Idea</a>
          <a href="/about" className="hover:underline">About</a>
          <a href="/#contact" className="hover:underline">Contact</a>
        </nav>
      </div>
    </header>
  )
}
```

Create `src/components/Footer.tsx`:
```tsx
export default function Footer() {
  return (
    <footer className="border-t">
      <div className="mx-auto max-w-6xl px-6 py-8 text-sm text-gray-600">
        <p>© {new Date().getFullYear()} AI-Blockchain. All rights reserved.</p>
      </div>
    </footer>
  )
}
```

--------------------------------------------------------------------------------
STEP 5 — Pages (Home/About/Idea) and cleanup
1) Overwrite `src/app/page.tsx` with:
```tsx
import { SITE } from '@/lib/site'

export default function HomePage() {
  return (
    <section className="mx-auto max-w-6xl px-6 py-16">
      <h1 className="text-4xl font-bold tracking-tight">{SITE.name}</h1>
      <p className="mt-4 text-lg text-gray-600">{SITE.description}</p>

      <div className="mt-8 flex gap-3">
        <a href="#features" className="rounded-xl bg-black px-5 py-3 text-white">Learn more</a>
        <a href="/about" className="rounded-xl border px-5 py-3">About</a>
      </div>

      <div id="features" className="mt-16 grid gap-6 sm:grid-cols-2">
        <div className="rounded-2xl border p-6">
          <h3 className="text-xl font-semibold">Proof-of-Compute</h3>
          <p className="mt-2 text-gray-600">Miners contribute GPU/CPU; the network measures, verifies, and rewards.</p>
        </div>
        <div className="rounded-2xl border p-6">
          <h3 className="text-xl font-semibold">AI-first design</h3>
          <p className="mt-2 text-gray-600">Training and inference as first-class citizens of the protocol.</p>
        </div>
      </div>

      <div id="contact" className="mt-20 rounded-2xl border p-6">
        <h2 className="text-2xl font-semibold">Contact</h2>
        <p className="mt-2 text-gray-600">
          Email us at <a className="underline" href="mailto:contact@example.com">contact@example.com</a>.
        </p>
      </div>
    </section>
  )
}
```

2) Create `src/app/about/page.tsx`:
```tsx
export const metadata = {
  title: 'About',
  description: 'Team and vision.',
}

export default function AboutPage() {
  return (
    <section className="mx-auto max-w-3xl px-6 py-12">
      <h1 className="text-3xl font-bold">About</h1>
      <p className="mt-4 text-gray-700">
        Tell the story, vision, and principles behind the project.
      </p>
    </section>
  )
}
```

3) Create `src/app/idea/page.tsx`:
```tsx
export const metadata = {
  title: 'The Idea',
  description: 'How mining ties to AI training and inference.',
}

export default function IdeaPage() {
  return (
    <section className="mx-auto max-w-3xl px-6 py-12">
      <h1 className="text-3xl font-bold">The Idea</h1>
      <p className="mt-4 text-gray-700">
        Present the mechanism: contributed compute, measurements, rewards, and security assumptions.
      </p>
    </section>
  )
}
```

4) Remove `src/app/page.module.css` if it exists (no longer used).

--------------------------------------------------------------------------------
STEP 6 — SEO routes
Create `src/app/sitemap.ts`:
```ts
import type { MetadataRoute } from 'next'
import { SITE } from '@/lib/site'

export default function sitemap(): MetadataRoute.Sitemap {
  return [
    { url: `${SITE.url}/`, lastModified: new Date() },
    { url: `${SITE.url}/about`, lastModified: new Date() },
    { url: `${SITE.url}/idea`, lastModified: new Date() },
  ]
}
```

Create `src/app/robots.ts`:
```ts
import type { MetadataRoute } from 'next'
import { SITE } from '@/lib/site'

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [{ userAgent: '*', allow: '/' }],
    sitemap: `${SITE.url}/sitemap.xml`,
  }
}
```

--------------------------------------------------------------------------------
STEP 7 — Public OG image placeholder
Create `public/og.svg` with this content:
```svg
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <defs>
    <linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#111827"/>
      <stop offset="1" stop-color="#1f2937"/>
    </linearGradient>
  </defs>
  <rect width="1200" height="630" fill="url(#g)"/>
  <text x="60" y="330" font-family="Inter, Arial, sans-serif" font-size="64" fill="#ffffff" font-weight="700">
    AI-Blockchain
  </text>
  <text x="60" y="390" font-family="Inter, Arial, sans-serif" font-size="28" fill="#d1d5db">
    Miners power AI and get paid
  </text>
</svg>
```

--------------------------------------------------------------------------------
STEP 8 — Run and verify
- In the `site/` terminal, run:
  - `npm install`
  - `npm run dev`
- Confirm the server starts on `http://localhost:3000`.
- Print a short summary of created/modified files.

DO NOT add any other libraries, env files, or AI integrations.
